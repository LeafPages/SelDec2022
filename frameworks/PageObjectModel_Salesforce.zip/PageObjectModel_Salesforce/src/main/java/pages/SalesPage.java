package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import base.BaseClass;
import io.cucumber.java.en.And;

public class SalesPage extends BaseClass{
	
	
    @And("Click on Opportunities")
    public SalesPage clickOpportunities() throws IOException {
    	WebElement opp = getDriver().findElement(By.xpath("//span[text()='Opportunities']"));
    	try {
			getDriver().executeScript("arguments[0].click();", opp);
			reportStep("Opportunities button is clicked successfully", "pass");
		} catch (Exception e) {
			reportStep("Opportunities button is not clicked successfully", "fail");
		}
    	return this;
	}
    
    @And("Click on New Button")
    public CreateOpportunityPage clickNew() throws IOException {
    try {
		getDriver().findElement(By.xpath("//div[@title='New']")).click();
		reportStep("New button is clicked", "pass");
	} catch (Exception e) {
		reportStep("New button is not clicked", "fail");
	} 	
   	return new CreateOpportunityPage();
	}
    
}
