package pages;

import org.openqa.selenium.By;


import base.BaseClass;
import io.cucumber.java.en.Then;

public class ViewOpportunityPage extends BaseClass{
	@Then("OpportunityName should be displayed")
   public ViewOpportunityPage verifyOpportunity() {
		String verifyMsg = getDriver().findElement(By.xpath("//span[contains(@class,'toastMessage')]/a"))
				.getAttribute("title");
		if (verifyMsg.contains(oppName)) {
			System.out.println("First OpportunityName verified successfully");
		}
		else if (verifyMsg.contains(oppName)) {
			System.out.println("Second OpportunityName verified successfully ");
		}
		else{
			System.out.println("Not verified");
		}
		return this;
	}
}