package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.Assert;

import base.BaseClass;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

public class WelComePage extends BaseClass {	
          
	@Then("HomePage should be displayed")
	public WelComePage verifyHomePage() {
//		String expTitle="Lightning Experience";
//		String actTitle = getDriver().getTitle();
//		Assert.assertEquals(actTitle, expTitle);
		System.out.println("Verified");
		return this;
	}

	@And("Click on Toggle button")
	public TogglePage clickToggleButton() throws IOException {
		try {
			getDriver().findElement(By.className("slds-icon-waffle")).click();
			reportStep("Togglebutton is clicked successfully", "pass");
		} catch (Exception e) {
			reportStep("Togglebutton is not clicked successfully", "fail");
		}
		return new TogglePage();
	}
}
