package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;

import base.BaseClass;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = "src/main/java/features", glue = "pages", monochrome = true, publish = true)
public class CucumberRunner extends BaseClass {
	@BeforeTest
	public void setValues() {
		testName="Salesforce Create Opportunity";
		testDescription="Create Opportunity for Salesforce application";
		testCategory="Sanity";
		testAuthor="Subraja";

	}
		
		 
}
