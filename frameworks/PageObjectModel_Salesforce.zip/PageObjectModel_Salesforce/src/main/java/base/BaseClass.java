package base;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcel;

public class BaseClass extends AbstractTestNGCucumberTests {

	private static final ThreadLocal<RemoteWebDriver> rd = new ThreadLocal<RemoteWebDriver>();
	
	public void setDriver(){
		ChromeOptions option = new ChromeOptions();
		option.addArguments("--disable-notifications");
		rd.set(new ChromeDriver(option));
	}
	
	public RemoteWebDriver getDriver() {
		return rd.get();
	}
	
	
	public String ExcelFileName;
	public static ExtentReports extent;
	public String testName, testDescription, testCategory, testAuthor;
	public static ExtentTest test,node;
	public static String oppName;

	@BeforeSuite
	public void startReport() {
		ExtentHtmlReporter reporter = new ExtentHtmlReporter("./reports/result.html");
		reporter.setAppendExisting(true);
		extent = new ExtentReports();
		extent.attachReporter(reporter);
	}

	@BeforeClass
	public void testcaseDetails() {
		test = extent.createTest(testName, testDescription);
		test.assignCategory(testCategory);
		test.assignAuthor(testAuthor);
	}

	public int takeSnap() throws IOException {
		int ranNum = (int) (Math.random() * 999999);
		File source = getDriver().getScreenshotAs(OutputType.FILE);
		File dest = new File("./snaps/img" + ranNum + ".png");
		FileUtils.copyFile(source, dest);
		return ranNum;

	}

	public void reportStep(String msg, String status) throws IOException {
		if (status.equalsIgnoreCase("pass")) {
			node.pass(msg,
					MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img" + takeSnap() + ".png").build());
		} else if (status.equalsIgnoreCase("fail")) {
			node.fail(msg,
					MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img" + takeSnap() + ".png").build());
		}

	}

	@BeforeMethod(alwaysRun=true)
	public void preCondition() {
		node = test.createNode(testName);
		setDriver();
		getDriver().manage().window().maximize();
		getDriver().get("https://login.salesforce.com/");
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

	}

	@AfterMethod(alwaysRun=true)
	public void postCondition() {
		getDriver().close();

	}

	@DataProvider(name = "fetchData")
	public String[][] sendData() throws IOException {
		return ReadExcel.readExcel(ExcelFileName);
	}

	@AfterSuite
	public void stopReport() {
		extent.flush();
	}

}
